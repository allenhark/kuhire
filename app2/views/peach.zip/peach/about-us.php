<section id="main">    
<div class="body-text">
<h1>about us</h1>
</div>


<div style="border: #686868 5px ; padding: 10px; -moz-border-radius: 15px; -webkit-border-radius: 15px">
      <div style="text-align: justify"><img style="display: inline; float: right" align="right" src="ADD IMAGE LINK HERE" width="128" height="128" /></div>

      <div style="text-align: justify">
	  <font color="#666666">

   Kuhire.com is a rental linking business owned by SCROBBER NETWORK SOLUTIONS LTD currently situated at BISHOP MAGUA CENTRE, GEORGE PADMORE LANE, NGONG RD.
We are here to ensure your rental needs are well catered for while friends can make money in the neighborhood by listening items they don’t use often.
<br /><br />
      <b>Our Team</b>
<ul align="center">
<li>Anyanzwa Brian </li>
<li>Antony Gitonga</li>
<li>Wilson Gitau </li>
<li>Merigi Kevin </li>
<li>Sam Gichuru (C.E.O NAILAB) - Member of the advisory board </li>
</ul>
<br />
      <div align="center">         
                    <a href="http://www.twitter.com/Kuhire254"><i class="icon-twitter-sign"> </i>Twitter</a>&nbsp &nbsp
                    <a href="http://www.facebook.com/Kuhire.com"><i class="icon-facebook-sign"> </i>Facebook Page</a>
       </div>         
    </font></div>
    </div>

 

  

   
</section>